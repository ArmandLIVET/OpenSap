sap.ui.define([
	"sap/ui/demo/odataV4/test/unit/controller/App.controller"
], function () {
	"use strict";
});