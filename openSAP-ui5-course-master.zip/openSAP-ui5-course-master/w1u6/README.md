#### Week 1 Unit 6 - Getting Ready for the Course Exercise ####

There is no coding exercise for this unit. Watch the video, sit back, and relax :-)

*The ui52 course team*

