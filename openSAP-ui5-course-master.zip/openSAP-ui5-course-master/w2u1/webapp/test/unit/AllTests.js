sap.ui.define([
	"opensap/movies/test/unit/controller/App.controller"
], function () {
	"use strict";
});